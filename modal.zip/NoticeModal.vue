<script setup>
import { useDialog } from '@/modules/dialog'
import { p } from '@/modules/config'
const props = defineProps({
  uid: { type: Number },
  content: { type: Object },
  message: { type: String },
  data: { type: Object }
})
const { closeModal } = useDialog()
</script>

<template>
  <v-card-text>
    <div>{{ props.message }}</div>
  </v-card-text>
  <v-card-actions>
    <v-spacer></v-spacer> <v-btn :text="p.OK" variant="text" @click="closeModal(data)"></v-btn>
  </v-card-actions>
</template>
