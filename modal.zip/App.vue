<script setup>
import { watch } from 'vue'
import { useRouter } from 'vue-router'
import { useAppStore } from '@/stores'
import { useDialog } from '@/modules/dialog'
import AppHeader from '@/layouts/AppHeader.vue'
import AppSidebar from '@/layouts/AppSidebar.vue'
import AppBody from '@/layouts/AppBody.vue'
import AppModal from '@/layouts/AppModal.vue'

const router = useRouter()
const { store } = useAppStore()
const { getModals } = useDialog()

watch(
  () => store.tabs.items.length,
  length => {
    console.log('length:', length)
    setTimeout(() => {
      if (!length) return router.replace('/')
      store.tabs.active = length ? length - 1 : 0
    }, 100)
  },
  { immediate: true }
)
</script>

<template>
  <AppHeader />
  <AppSidebar />
  <AppBody />
  <Teleport to="body" v-for="modal in getModals()" :key="modal.uid">
    <AppModal
      v-if="modal.visible"
      :uid="modal.uid"
      :width="modal.width"
      :title="modal.title"
      :content="modal.content"
      :message="modal.message"
      :data="modal.data"
      :visible="modal.visible"
    />
  </Teleport>
</template>

<style>
/* 
body {
  font-size: 14px;
}
header {
  position: fixed;
  top: 0;
  left: 0;
  height: 40px;
  width: 100%;
  border-bottom: 1px solid #dfdfdf;
  background: #fff;
  z-index: 1;
  text-align: center;
}
aside {
  position: fixed;
  top: 40px;
  left: 0;
  height: calc(100% - 40px);
  width: 300px;
  border-right: 1px solid #dfdfdf;
  background: #fff;
}
aside .top {
  text-align: right;
  padding: 4px;
}
aside nav ul li {
  padding: 2px;
  margin: 8px;
  border: 1px solid #ccc;
}

main {
  flex: 1 0 auto;
  margin: 40px auto auto 300px;
}

.container {
  padding: 20px;
  min-height: 300px;
  text-align: center;
}

footer {
  height: 100px;
  width: 100%;
  border-top: 1px solid #dfdfdf;
  padding: 20px 0 0 20px;
  text-align: center;
}
nav a {
  padding: 10px 20px 0;
} */
</style>
