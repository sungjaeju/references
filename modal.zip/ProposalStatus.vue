<script setup>
import { useDialog } from '@/modules/dialog'
import { f, p } from '@/modules/config'

const { openModal } = useDialog()

const openDataModal = async () => {
  const resolve = await openModal(f.MODAL_NAME.CONFIRM, p.LIMIT_TAB, { a: 1, b: 2 })
  console.log('resolve:', resolve.data)
}
</script>

<template>
  <div>PROPOSAL-SEARCH</div>
  <v-card>
    <v-btn @click="openDataModal">모달 열기</v-btn>
  </v-card>
</template>
