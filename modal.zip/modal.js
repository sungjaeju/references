import { ref } from 'vue'

import context from './modal-context'

/**

 * Modal structure

 */

const modal = ref({
  items: [],

  store: {}
})

/**

 * Gets all modals

 * @returns 모든 모달창 조회

 */

const getModals = () => {
  return modal.value.items
}

/**

 * Is the modal item visible?

 * @param {Number} uid 모달창 고유 번호

 * @returns 모달창 활성 상태

 */

const isModalVisible = uid => {
  modal.value.items.forEach(item => {
    if (item.uid == uid) {
      console.debug('isModalVisible:', item)

      return item.visible
    }
  })
}

/**

 * Opens a modal

 * @param {String} name 모달창 고유 이름

 * @returns Promise

 */

const openModal = (name, message = '', data = {}) => {
  console.log('openModal.data:', data)
  if (!name) return console.error('It must have a modal name specified.')

  const item = {
    uid: Date.now(),

    width: context[name]().width || '800px',

    title: context[name]().title || '',

    content: context[name]().content,

    message: message,

    data: data,

    visible: true,

    promise: null,

    resolve: null,

    reject: null
  }

  item.promise = new Promise((resolve, reject) => {
    item.resolve = resolve

    item.reject = reject
  })

  modal.value.items.push(item)

  console.debug('modal.value.items:', modal.value.items)

  return item.promise
}

/**

 * Closes a modal

 * @param {Number} uid 모달창 고유 번호

 * @param {*} status 처리 상태

 */

const closeModal = (uid, data = {}) => {
  if (!uid) return console.error('It must have the modal uid.')

  const resolve = {
    uid,
    data
  }
  const left = modal.value.items
    .map(item => {
      if (item.uid == uid) {
        item.visible = false

        item.resolve(resolve)
      }

      return item
    })

    .filter(item => item.uid != uid)

  console.debug('left.modals:', left)

  modal.value.items = left
}

export default modal

export { getModals, isModalVisible, openModal, closeModal }
