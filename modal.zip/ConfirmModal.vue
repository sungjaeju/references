<script setup>
import { useDialog } from '@/modules/dialog'
import { p } from '@/modules/config'

const props = defineProps({
  uid: {
    type: Number
  },
  content: {
    type: Object
  },
  message: {
    type: String
  },
  data: {
    type: Object
  }
})

const { closeModal } = useDialog()
console.log('confirm.data:', props.data)
</script>

<template>
  <v-card-text>
    <div>{{ props.message }}</div>
  </v-card-text>
  <v-card-actions>
    <v-spacer></v-spacer>
    <v-btn :text="p.OK" variant="text" @click="closeModal(props.uid, props.data)"></v-btn>
    <v-btn :text="p.CANCEL" variant="text" @click="closeModal(props.uid)"></v-btn>
  </v-card-actions>
</template>
