<script setup>
import { toRef } from 'vue'
import { useDialog } from '@/modules/dialog'

const props = defineProps({
  uid: {
    type: Number
  },
  width: {
    type: String
  },
  title: {
    type: String
  },
  content: {
    type: Object
  },
  message: {
    type: String
  },
  data: {
    type: Object
  },
  visible: {
    type: Boolean
  }
})

const { closeModal } = useDialog()
const dialog = toRef(props, 'visible')
</script>

<template>
  <div class="pa-4 text-center" v-if="props.content">
    <v-dialog v-model="dialog" :max-width="props.width" persistent="">
      <v-card rounded="lg">
        <v-card-title class="d-flex justify-space-between align-center">
          <div class="text-h5 text-medium-empahsis ps-2">{{ props.title }}</div>
          <v-btn icon="mdi-close" variant="text" @click="closeModal(props.uid)"></v-btn>
        </v-card-title>
        <component
          :uid="props.uid"
          :message="props.message"
          :data="props.data"
          :is="props.content"
        />
      </v-card>
    </v-dialog>
  </div>
</template>
